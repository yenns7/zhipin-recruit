# 智聘 MVP 部署交接说明

这是给公司服务器部署用的智聘 MVP 包，不是本地测试网址。

## 包里有什么

- 前后端源码
- 前端构建产物：`frontend/dist/`
- 清理后的数据库：`backend/hireinsight.db`
- 后端依赖：`backend/requirements.txt`
- 环境变量模板：`backend/.env.example`

## 当前数据状态

- 真实业务数据已清空
- 候选人、流程、面试数据为空
- 保留演示账号、基础配置和 4 个演示岗位
- 上传测试文件未放入包内

## 演示账号

统一密码：`Zhipin2026`

常用账号：

```text
admin01@mvp.local
manager01@mvp.local
hr01@mvp.local
interviewer01@mvp.local
```

## 研发部署前请确认

- 从 `backend/.env.example` 复制并配置 `backend/.env`
- 服务器创建可写目录：`backend/uploads/`
- 前端静态文件使用 `frontend/dist/`
- `/api` 请求转发到后端服务
- 域名、HTTPS、日志、备份、回滚按公司规范配置

## 当前版本边界

当前版本是 MVP 试点版，主流程已可用。

暂不包含：

- OA 自动发起招聘需求
- AI 深度解析和复杂评分
- 二级、三级复杂看板
- 完整生产级审批、监控和合规流程

交接前验证：

```text
后端全量测试：183 passed
前端静态测试：通过
前端 TypeScript 检查：通过
前端生产构建：通过
数据库完整性检查：ok
```
